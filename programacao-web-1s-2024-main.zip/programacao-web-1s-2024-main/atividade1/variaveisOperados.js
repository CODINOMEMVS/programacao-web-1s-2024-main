const a = 2;
const b = 3;
const d = "2";
const e = "3";

let c = a + b;
console.log('O resultado da soma entre ' + a + ' e ' + b + ' é ' + c);

c = a - b; 
console.log(`O resultado da subtração entre ${a} e ${b} é ${c}`);

c = a * b;
console.log(`O resultado da multiplicação entre ${a} e ${b} é ${c}`);

c = a / b;
console.log(`O resultado da divisão entre ${a} e ${b} é ${c}`);

console.log(`O resultado da soma entre ${d} e ${e} é ${d + e}`);
