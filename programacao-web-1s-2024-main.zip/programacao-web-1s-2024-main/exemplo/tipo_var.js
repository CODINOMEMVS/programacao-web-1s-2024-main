const j = 1;
console.log('j = ' + j)
var n = 1.5;
var n = 2.3;
console.log('n = ' + n)

let m = 1;
m = 2.000001;
console.log('m = ' + m)

const minhaString = 'Ab"C"d'
console.log(minhaString)

let booleanA = true;
let booleanB = false;

booleanA = 0;
booleanB = -1;

if(booleanA){
    console.log('booleanA')
}

if(booleanB){
    console.log('booleanB')
}

let nulo = null;
let u;
console.log(nulo)
console.log(u)


let a = 2
let b = 3
let c = a + b
console.log(`Resultado da + entre ${a} e ${b} = ${c}`)
console.log("Resultado da + entre "+ a +" e "+ b +" = " + c)